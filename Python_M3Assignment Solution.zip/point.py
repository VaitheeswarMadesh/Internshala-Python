def calculate_points(player):
    point=0

    #calculating point for batsman
    
    if(player['role']=='bat'):
        point+=player['runs'] //2
        
        if(player['runs'] >= 50):
            point+=5
            if(player['runs']>=100):
                point+=10
                
        strike_rate=player['runs']/player['balls']*100
        if(strike_rate>=80 and strike_rate<=100):
            point+=2
        elif(strike_rate>100):
            point+=4

        point+=player['4']*1
        point+=player['6']*2
        point+=player['field']*10
        
        player_point={'name':player['name'],'batscore':point}
        print(player_point)
        
    #calculating point for bowlers
        
    elif(player['role']=='bowl'):
        point+=player['wkts']*10

        if(player['wkts']>=3):
            point+=5
            if(player['wkts']>=5):
                point+=10
        economy_rate=player['runs']/player['overs']

        if(economy_rate>3.5 and economy_rate<=4.5):
            point+=4
        elif(economy_rate>=2 and economy_rate<=3.5):
            point+=7
        elif(economy_rate<2):
            point+=10    
        point+=player['field']*10
        
        player_point={'name':player['name'],'batscore':point}
        print(player_point)
    return  

