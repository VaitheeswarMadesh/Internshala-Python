class book:
    def __init__(self):
        self.title=input("enter Book title:")
        self.author=input("enter Book author name:")
        self.publisher=input("enter Book publisher name: ")
        self.price=int(input("enter price of book:"))

    def setter(self):
        self.title=input("enter Book title:")
        self.author=input("enter Book author name:")
        self.publisher=input("enter Book publisher name: ")
        self.price=int(input("enter price of book:"))
        return


    def getter(self):
        print("Book title : {} \n Book author name : {}\n Book publisher : {} \n Book price : {}".format(self.title,self.author,self.publisher,self.price))
        return

    def royalty(self,sale):
        if(sale<=500):
            self.royalty=self.price*0.10
            return self.royalty
        elif(sale<=1000):
            self.royalty=self.price*0.125
            return self.royalty
        else:
            self.royalty=self.price*0.15
            return self.royalty

class ebook(book):
    def __init__(self):
        super().__init__()
        self.format=input("enter format of ebook like (EPUB, PDF,MOBI ETC): ")

    def royalty(self,sale):       # 12% GST included
        
        if(sale<=500):
            
            self.royalty=(self.price-self.price*0.12)*0.10
            return self.royalty
        elif(sale<=1000):
            self.royalty=(self.price-self.price*0.12)*0.125
            return self.royalty
        else:
            self.royalty=(self.price-self.price*0.12)*0.15
            return self.royalty

# main code

b1=book()
sale=int(input("enter total sales of book : "))
print("royalty amount on Book is:",b1.royalty(sale))

eb1=ebook()
sale=int(input("enter total sales of ebook :"))
print("royalty amount on Book is:",eb1.royalty(sale))
    
    









    

        
